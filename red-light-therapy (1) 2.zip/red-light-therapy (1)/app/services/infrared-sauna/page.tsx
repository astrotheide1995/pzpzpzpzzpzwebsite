import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Flame, Heart, Droplets } from "lucide-react"

export default function InfraredSaunaPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 decorative-pattern opacity-10"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center lg:flex-row lg:justify-between">
            <div className="mb-10 max-w-xl lg:mb-0 lg:pr-8">
              <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
                Full Spectrum
                <span className="block bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
                  Infrared Sauna
                </span>
              </h1>
              <p className="mb-8 text-xl text-gray-600">
                Experience the ultimate in detoxification and relaxation with our state-of-the-art Sunlighten infrared
                saunas. Enhance your wellness journey with the power of therapeutic heat.
              </p>
              <Button asChild size="lg" className="text-lg">
                <Link href="/contact">
                  Book Your Session <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
            <div className="relative h-64 w-full overflow-hidden rounded-2xl shadow-2xl lg:h-[500px] lg:w-2/3">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sauna%202-gvqPnm6OGXEbFqJjJ7HsFwbcrj76U3.jpeg"
                alt="Sunlighten Infrared Sauna"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Features Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16 grid gap-8 md:grid-cols-2">
            <div className="relative h-96 overflow-hidden rounded-lg shadow-lg">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Sauna%201-dIJvtmjDo7bxiSGi3GsfDfESoP3Nvi.jpeg"
                alt="Dual Sunlighten Saunas"
                fill
                className="object-cover"
              />
            </div>
            <div className="flex flex-col justify-center">
              <h2 className="mb-6 text-3xl font-bold text-gray-900">Premium Sunlighten Technology</h2>
              <p className="mb-6 text-lg text-gray-600">
                Our Signature infrared saunas combine the latest in infrared technology with premium craftsmanship.
                Experience the perfect blend of comfort and therapeutic benefits in our private sauna suites.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <Flame className="mr-2 h-5 w-5 text-red-600" />
                  <span>Full spectrum infrared coverage</span>
                </li>
                <li className="flex items-center">
                  <Heart className="mr-2 h-5 w-5 text-red-600" />
                  <span>Therapeutic-grade heating technology</span>
                </li>
                <li className="flex items-center">
                  <Droplets className="mr-2 h-5 w-5 text-red-600" />
                  <span>Enhanced detoxification benefits</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Grid */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">Health Benefits</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "Weight Loss",
                description: "Burn calories and accelerate metabolism through passive cardiovascular conditioning.",
              },
              {
                title: "Detoxification",
                description: "Eliminate toxins through deep sweating at the cellular level.",
              },
              {
                title: "Pain Relief",
                description: "Reduce inflammation and ease muscle tension with therapeutic infrared heat.",
              },
              {
                title: "Better Sleep",
                description: "Promote deeper, more restful sleep through relaxation and stress reduction.",
              },
              {
                title: "Skin Health",
                description: "Improve skin tone and reduce signs of aging by increasing collagen production.",
              },
              {
                title: "Heart Health",
                description:
                  "Support cardiovascular health through improved circulation and blood pressure regulation.",
              },
            ].map((benefit, index) => (
              <div key={index} className="rounded-lg bg-white p-6 shadow-lg transition-all hover-card">
                <h3 className="mb-3 text-xl font-semibold text-gray-900">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Session Information */}
      <section className="bg-white py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl">
            <h2 className="mb-8 text-center text-3xl font-bold text-gray-900">Your Sauna Experience</h2>
            <div className="rounded-lg bg-gray-50 p-8 shadow-lg">
              <div className="mb-8">
                <h3 className="mb-4 text-xl font-semibold text-gray-900">What to Expect</h3>
                <ul className="space-y-3 text-gray-600">
                  <li>• Private sauna suite with ambient lighting</li>
                  <li>• Temperature control for optimal comfort</li>
                  <li>• 30-45 minute recommended session time</li>
                  <li>• Complimentary towel service</li>
                  <li>• Shower facilities available</li>
                </ul>
              </div>
              <div>
                <h3 className="mb-4 text-xl font-semibold text-gray-900">Preparation Tips</h3>
                <ul className="space-y-3 text-gray-600">
                  <li>• Hydrate well before and after your session</li>
                  <li>• Wear comfortable, loose-fitting clothing</li>
                  <li>• Avoid heavy meals before your session</li>
                  <li>• Bring additional towels if desired</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-400 py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Experience the Power of Infrared Therapy</h2>
            <p className="mb-8 text-lg">
              Join us for a relaxing and rejuvenating sauna session. Book your first visit today and discover the
              benefits for yourself.
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href="/contact">
                Book Your Session <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}


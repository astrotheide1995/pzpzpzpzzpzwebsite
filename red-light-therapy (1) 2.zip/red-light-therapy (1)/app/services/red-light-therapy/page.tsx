import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Heart, Brain, Check, Star } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function RedLightTherapyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 decorative-pattern opacity-10"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center lg:flex-row lg:justify-between lg:space-x-8">
            <div className="mb-10 max-w-xl lg:mb-0 lg:w-2/5">
              <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
                <span className="block text-red-600">Transform</span>
                <span className="block">Your Body With</span>
                <span className="block bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
                  The Power of Light
                </span>
              </h1>
              <p className="mb-8 text-xl text-gray-600 leading-relaxed">
                Achieve your body goals without surgery, pain, or downtime. Our advanced red light therapy treatments
                target stubborn fat, reduce inches, and contour your body naturally.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="text-lg">
                  <Link href="/contact">
                    Start Your Transformation <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="text-lg">
                  <Link href="#learn-more">Learn More</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-64 w-full overflow-hidden rounded-2xl shadow-2xl lg:h-[500px] lg:w-3/5">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1982.JPG-jhzj4guuFYKP20zCKnNNapba0idvic.jpeg"
                alt="Red light therapy treatment"
                fill
                className="object-cover object-center"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 60vw, 70vw"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* What is Red Light Therapy Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">What is Red Light Therapy?</h2>
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <p className="mb-6 text-lg text-gray-600">
                Red light therapy, also known as low-level laser therapy (LLLT) or photobiomodulation, uses specific
                wavelengths of red light to penetrate the skin and stimulate cellular processes. For body contouring,
                these specialized light wavelengths target fat cells, creating temporary pores in their membranes that
                allow stored fat to be released and naturally eliminated by the body's lymphatic system.
              </p>
            </div>
            <div>
              <h3 className="mb-4 text-2xl font-semibold text-gray-900">Key Benefits</h3>
              <ul className="space-y-3">
                {[
                  "Non-invasive, painless treatment",
                  "No recovery time or downtime",
                  "Clinically proven technology",
                  "Natural body contouring solution",
                  "Complements healthy lifestyle choices",
                ].map((benefit, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="mr-2 h-5 w-5 text-green-500" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">
            How Red Light Therapy Works for Inch Loss
          </h2>
          <div className="mx-auto max-w-3xl">
            <h3 className="mb-6 text-2xl font-semibold text-gray-900">The Science Behind the Results</h3>
            <p className="mb-8 text-lg text-gray-600">
              Red light therapy operates at the cellular level, using specific wavelengths (typically 630-670
              nanometers) that penetrate beneath the skin surface to reach fat cells. Unlike surgical options, this
              technology works with your body's natural processes:
            </p>
            <ol className="space-y-4">
              {[
                "Fat Cell Stimulation: Light energy penetrates the skin to reach fat cells",
                "Temporary Pore Formation: Fat cell membranes develop temporary openings",
                "Fat Release: Stored triglycerides and fatty acids exit the cells",
                "Natural Elimination: Your lymphatic system processes and removes the released fat",
                "Cell Shrinkage: Empty fat cells shrink, resulting in inch loss and body contouring",
              ].map((step, index) => (
                <li key={index} className="flex items-start">
                  <span className="mr-2 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-600 text-sm font-bold text-white">
                    {index + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
            <p className="mt-6 text-lg text-gray-600">
              This process results in measurable inch loss in targeted areas while maintaining the integrity of
              surrounding tissues, blood vessels, and skin.
            </p>
          </div>
        </div>
      </section>

      {/* Weight Loss Support Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">
            Weight Loss Support Through Red Light Therapy
          </h2>
          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                title: "Metabolic Enhancement",
                description:
                  'Research suggests red light therapy may help boost your metabolism by stimulating mitochondria—the cellular "power plants" that convert nutrients into energy. Enhanced mitochondrial function may increase caloric burn throughout the day.',
                icon: Zap,
              },
              {
                title: "Reduced Inflammation",
                description:
                  "Chronic inflammation can interfere with weight loss efforts. Red light therapy has anti-inflammatory properties that may help optimize your body's natural fat-burning capabilities.",
                icon: Heart,
              },
              {
                title: "Improved Exercise Recovery",
                description:
                  "Faster recovery between workouts means more consistent exercise routines. Red light therapy has been shown to reduce muscle soreness and speed recovery, potentially leading to more frequent and effective workouts.",
                icon: Brain,
              },
            ].map((item, index) => (
              <div key={index} className="rounded-lg bg-gray-50 p-6 shadow-lg hover-card">
                <item.icon className="mb-4 h-12 w-12 text-red-600" />
                <h3 className="mb-3 text-xl font-semibold text-gray-900">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-lg text-gray-600 italic">
            Note: Red light therapy works best as part of a comprehensive approach that includes healthy eating and
            regular physical activity.
          </p>
        </div>
      </section>

      {/* Treatment Areas Section */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-900">Treatment Areas</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              { area: "Abdomen", description: "Tighten and tone your midsection" },
              { area: "Flanks/Love Handles", description: "Smooth your silhouette" },
              { area: "Thighs", description: "Reduce circumference of inner and outer thighs" },
              { area: "Arms", description: "Firm and contour upper arm areas" },
              { area: "Back", description: "Diminish bra bulge and back fat" },
              { area: "Chin/Neck", description: "Reduce double chin appearance" },
            ].map((item, index) => (
              <div key={index} className="rounded-lg bg-white p-6 shadow-md">
                <h3 className="mb-2 text-xl font-semibold text-gray-900">{item.area}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-lg text-gray-600">
            Most clients experience optimal results when treating 2-3 areas over a series of sessions.
          </p>
        </div>
      </section>

      {/* Treatment Process Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">What to Expect: The Treatment Process</h2>
          <div className="mx-auto max-w-3xl">
            <h3 className="mb-6 text-2xl font-semibold text-gray-900">Your Red Light Therapy Journey</h3>
            <div className="mb-8 rounded-lg bg-gray-50 p-6 shadow-md">
              <h4 className="mb-4 text-xl font-semibold text-gray-900">Initial Consultation</h4>
              <p className="text-gray-600">
                Our experts will assess your goals, medical history, and body composition to create a personalized
                treatment plan tailored to your needs.
              </p>
            </div>
            <div className="mb-8 rounded-lg bg-gray-50 p-6 shadow-md">
              <h4 className="mb-4 text-xl font-semibold text-gray-900">Treatment Sessions</h4>
              <ul className="space-y-2 text-gray-600">
                <li>• Each session lasts approximately 20-30 minutes</li>
                <li>• Treatments are comfortable and painless</li>
                <li>• You'll remain fully clothed or in minimal clothing depending on treatment areas</li>
                <li>• Many clients describe the experience as relaxing and warm</li>
              </ul>
            </div>
            <div className="rounded-lg bg-gray-50 p-6 shadow-md">
              <h4 className="mb-4 text-xl font-semibold text-gray-900">Recommended Protocol</h4>
              <p className="mb-4 text-gray-600">For optimal results, we typically recommend:</p>
              <ul className="space-y-2 text-gray-600">
                <li>• 2-3 sessions per week</li>
                <li>• 6-12 week treatment course</li>
                <li>• Maintenance sessions as needed</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Client Results & Testimonials Section */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-900">Client Results & Testimonials</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                quote:
                  "After having two children, I struggled with stubborn belly fat that wouldn't budge despite diet and exercise. After 8 weeks of red light therapy treatments, I've lost 3 inches from my waist and feel confident in my clothes again!",
                author: "Jennifer M.",
              },
              {
                quote:
                  "As a 45-year-old man, I was skeptical about non-surgical body contouring. The results speak for themselves—my love handles are significantly reduced and my pants fit better than they have in years.",
                author: "Michael T.",
              },
              {
                quote:
                  "I've tried everything for my thighs with minimal results. Red light therapy has been the only treatment that's actually made a visible difference. I'm down 2.5 inches total and still seeing improvements!",
                author: "Sarah K.",
              },
            ].map((testimonial, index) => (
              <div key={index} className="rounded-lg bg-white p-6 shadow-lg">
                <div className="mb-4 flex justify-center">
                  <Star className="h-8 w-8 text-yellow-400" />
                  <Star className="h-8 w-8 text-yellow-400" />
                  <Star className="h-8 w-8 text-yellow-400" />
                  <Star className="h-8 w-8 text-yellow-400" />
                  <Star className="h-8 w-8 text-yellow-400" />
                </div>
                <p className="mb-4 text-gray-600 italic">"{testimonial.quote}"</p>
                <p className="text-right font-semibold">— {testimonial.author}</p>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-sm text-gray-500">
            Individual results may vary. Best results achieved when combined with healthy lifestyle choices.
          </p>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">Frequently Asked Questions</h2>
          <div className="mx-auto max-w-3xl">
            <Accordion type="single" collapsible className="w-full">
              {[
                {
                  question: "Is red light therapy safe?",
                  answer:
                    "Yes! Red light therapy is FDA-cleared for body contouring and has an excellent safety profile with minimal side effects. The treatment is non-invasive and pain-free.",
                },
                {
                  question: "How soon will I see results?",
                  answer:
                    "Many clients notice changes after 4-6 sessions, with optimal results typically visible after completing a full treatment protocol of 12-18 sessions.",
                },
                {
                  question: "How much inch loss can I expect?",
                  answer:
                    "Results vary based on individual factors, but many clients experience 1-3 inches of reduction in treated areas after a full treatment course.",
                },
                {
                  question: "Is the inch loss permanent?",
                  answer:
                    "Results can be long-lasting when maintained with a healthy lifestyle. The fat cells are emptied but not destroyed, so they can refill if caloric intake consistently exceeds expenditure.",
                },
                {
                  question: "Does it hurt?",
                  answer:
                    "No, red light therapy is painless. Most clients experience a gentle warming sensation and find the treatments relaxing.",
                },
                {
                  question: "Is there any downtime?",
                  answer: "None! You can immediately return to all normal activities following treatment.",
                },
              ].map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* About Our Technology Section */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-900">About Our Technology</h2>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-8 text-lg text-gray-600">
              Our clinic uses the advanced [Device Name] system, the latest generation of red light therapy technology
              specifically designed for body contouring and inch loss.
            </p>
            <h3 className="mb-6 text-2xl font-semibold text-gray-900">Key Features:</h3>
            <ul className="mb-8 space-y-2 text-left text-gray-600">
              <li>• FDA-cleared for safety and efficacy</li>
              <li>• Patented wavelength technology</li>
              <li>• Uniform light distribution for consistent results</li>
              <li>• Customizable treatment protocols</li>
              <li>• Comfortable application system</li>
            </ul>
            <p className="text-gray-600">
              Our systems undergo regular calibration and maintenance to ensure optimal performance and results.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-400 py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Ready to Transform Your Body?</h2>
            <p className="mb-8 text-lg">
              Experience the power of red light therapy for yourself. Book your consultation today and take the first
              step towards your body goals.
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href="/contact">
                Schedule Your Consultation <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}


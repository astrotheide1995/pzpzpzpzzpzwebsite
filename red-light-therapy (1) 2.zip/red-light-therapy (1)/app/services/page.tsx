import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Zap, Sun, Heart } from "lucide-react"

export default function ServicesPage() {
  const services = [
    {
      title: "Red Light Inch Loss",
      description:
        "Target specific areas for inch reduction using advanced red light therapy that helps break down fat cells naturally.",
      icon: Sun,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1982.JPG-jhzj4guuFYKP20zCKnNNapba0idvic.jpeg",
    },
    {
      title: "Laser-Like Lipo",
      description:
        "Experience a non-invasive alternative to traditional liposuction, using red light technology to target and reduce fat without surgery.",
      icon: Zap,
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Medwave%201-FBhiU0IElRF6TwjznR9nBFCvJegJWE.jpeg",
    },
    {
      title: "Wellness Therapy",
      description:
        "Enjoy comprehensive red light treatments that improve overall wellness, reduce inflammation, and enhance cellular function.",
      icon: Heart,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Medwave%20Consultation%201-ZYW0XxFhk2WKuz54uf3tKhxLuYRvI0.jpeg",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 bg-[url('/grid-pattern.svg')] opacity-5"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
              Our{" "}
              <span className="bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">Innovative</span>{" "}
              Services
            </h1>
            <p className="mb-8 text-xl text-gray-600">
              Discover our range of non-invasive, cutting-edge treatments designed to help you achieve your body goals.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="mb-6 rounded-full bg-red-100 p-4">
                  <service.icon className="h-12 w-12 text-red-600" />
                </div>
                <h2 className="mb-4 text-2xl font-bold text-gray-900">{service.title}</h2>
                <p className="mb-6 text-gray-600">{service.description}</p>
                <div className="relative h-64 w-full overflow-hidden rounded-lg shadow-lg">
                  <Image
                    src={service.image || "/placeholder.svg"}
                    alt={service.title}
                    fill
                    className="object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <Button asChild size="lg" className="mt-6 text-lg">
                  <Link href="/contact">
                    Learn More <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-400 py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Ready to Transform Your Body?</h2>
            <p className="mb-8 text-lg">
              Experience the future of body contouring and wellness. Start your journey to a healthier, more confident
              you today.
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href="/contact">
                Schedule Your Consultation <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}


import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Users, Award, ThumbsUp } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 bg-[url('/grid-pattern.svg')] opacity-5"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center lg:flex-row lg:justify-between">
            <div className="mb-10 max-w-xl lg:mb-0 lg:pr-8 lg:w-1/2">
              <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
                Our Mission:
                <br />
                <span className="bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
                  Empowering You To Live Healthier, Longer
                </span>
              </h1>
              <p className="mb-8 text-xl text-gray-600">
                At Atlanta Laser Like Lipo, we believe real transformation comes from addressing the root causes of
                weight gain and unhealthy habits. Our mission is to provide safe, cutting-edge, and integrative
                solutions that nurture both body and mind for lasting results.
              </p>
            </div>
            <div className="relative h-64 w-full overflow-hidden rounded-2xl shadow-2xl lg:h-[500px] lg:w-2/3">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Bryant%20Belinda%20Robert%201-UDR2l8ZUPnwTDZPpN3v9IZceXfNvO4.jpeg"
                alt="Our team"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </section>

      {/* What Makes Us Different */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900 sm:text-4xl">What Makes Us Different</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: Award,
                title: "GMP Certified Partnerships",
                description: "We only use whole-food supplements from trusted, FDA-compliant manufacturers.",
              },
              {
                icon: Users,
                title: "Evidence-Based Technologies",
                description:
                  "Our Red Light Therapy and Laser-Like Lipo devices are FDA Registered or Cleared, ensuring safety and efficacy.",
              },
              {
                icon: ThumbsUp,
                title: "Personalized Programs",
                description:
                  "No one-size-fits-all approaches here. Your goals, lifestyle, and preferences shape your unique plan.",
              },
            ].map((feature, index) => (
              <div key={index} className="rounded-xl bg-gray-50 p-6 shadow-lg transition-all hover:shadow-xl">
                <feature.icon className="mb-4 h-10 w-10 text-red-600" />
                <h3 className="mb-2 text-xl font-semibold text-gray-900">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Commitment */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold text-gray-900 sm:text-4xl">Our Commitment to You</h2>
            <p className="mb-8 text-lg text-gray-600">
              Whether you're looking to drop a few inches, boost your energy, or overhaul your dietary habits, our team
              is here to guide you—not pressure you. We'll conduct an in-depth consultation to learn about your health
              history, personal goals, and even your daily schedule. If we find that you need additional care beyond
              what we offer, we'll connect you with the right professionals. At the end of the day, our goal is simple:
              help you achieve and maintain the vibrant lifestyle you deserve.
            </p>
            <Button asChild size="lg" className="text-lg">
              <Link href="/contact">
                Schedule a Consultation <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}


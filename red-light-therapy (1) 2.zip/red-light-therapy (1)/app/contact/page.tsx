import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowRight, Phone, Mail, MapPin } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 bg-[url('/grid-pattern.svg')] opacity-5"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
              Ready to{" "}
              <span className="bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">Begin</span> Your
              Transformation?
            </h1>
            <p className="mb-8 text-xl text-gray-600">
              We'd love to hear from you. Whether you're booking your $89 Intro Session or simply exploring options,
              we're here to help.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-2">
            <div className="rounded-xl bg-gray-50 p-8 shadow-lg">
              <h2 className="mb-6 text-2xl font-bold text-gray-900">Get in Touch</h2>
              <form className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Input placeholder="First Name" />
                  <Input placeholder="Last Name" />
                </div>
                <Input type="email" placeholder="Email" />
                <Input type="tel" placeholder="Phone" />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a service" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="red-light">Red Light Inch Loss</SelectItem>
                    <SelectItem value="laser-lipo">Laser-Like Lipo</SelectItem>
                    <SelectItem value="wellness">Wellness Therapy</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea placeholder="Your message" rows={4} />
                <Button type="submit" size="lg" className="w-full text-lg">
                  Send Message <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </div>
            <div className="space-y-8">
              <div>
                <h2 className="mb-4 text-2xl font-bold text-gray-900">Contact Information</h2>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <Phone className="mr-4 h-6 w-6 text-red-600" />
                    <p className="text-lg text-gray-600">(770) 702-4629</p>
                  </div>
                  <div className="flex items-center">
                    <Mail className="mr-4 h-6 w-6 text-red-600" />
                    <p className="text-lg text-gray-600">info@atlantalaserlipo.com</p>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="mr-4 h-6 w-6 text-red-600" />
                    <p className="text-lg text-gray-600">
                      3035 Five Forks Trickum Rd
                      <br />
                      Suite 7<br />
                      Lilburn, GA 33047
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <h2 className="mb-4 text-2xl font-bold text-gray-900">Business Hours</h2>
                <p className="text-lg text-gray-600">
                  Monday - Friday: 9AM - 7PM
                  <br />
                  Saturday: 10AM - 4PM
                  <br />
                  Sunday: Closed
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-400 py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Ready to Take the First Step?</h2>
            <p className="mb-8 text-lg">
              Book your $89 Intro Session today and start your journey towards a healthier, more confident you.
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href="/contact">
                Book Your Intro Session <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <p className="mt-4 text-sm opacity-80">48-hour cancellation policy applies. See terms for details.</p>
          </div>
        </div>
      </section>
    </div>
  )
}


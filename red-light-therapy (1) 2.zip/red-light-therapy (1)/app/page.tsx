import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle, Zap, Users, Sparkles } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Quote } from "lucide-react"

export default function Home() {
  const faqs = [
    {
      question: "How does red light therapy work?",
      answer:
        "Red light therapy uses low-level wavelengths of light to stimulate cellular function, promoting fat loss and skin rejuvenation. It works by increasing cellular energy production, which can lead to improved metabolism and faster healing.",
    },
    {
      question: "Is the treatment painful?",
      answer:
        "No, our treatments are non-invasive and pain-free. Most clients find the experience relaxing and comfortable. You may feel a gentle warmth during the session, but there should be no discomfort.",
    },
    {
      question: "How many sessions will I need?",
      answer:
        "The number of sessions varies based on individual goals, but most clients see results within 6-12 sessions. We recommend starting with a series of 8-10 treatments, scheduled 2-3 times per week for optimal results.",
    },
    {
      question: "Are there any side effects?",
      answer:
        "Red light therapy is generally safe with no known side effects when administered properly. Some people may experience temporary redness or tightness in the treated area, but this typically subsides quickly.",
    },
    {
      question: "How long does each session last?",
      answer:
        "Each session typically lasts between 15 to 30 minutes, depending on the treatment area and your specific needs. Our specialists will determine the optimal treatment time for your individual case.",
    },
    {
      question: "Can I combine red light therapy with other treatments?",
      answer:
        "Yes, red light therapy can often be combined with other treatments for enhanced results. We offer customized treatment plans that may include a combination of therapies to best meet your goals.",
    },
    {
      question: "How soon can I expect to see results?",
      answer:
        "While individual results may vary, many clients report seeing noticeable improvements after 4-6 sessions. Optimal results are typically achieved after a full treatment course of 8-12 sessions.",
    },
    {
      question: "Is red light therapy safe for all skin types?",
      answer:
        "Yes, red light therapy is generally safe for all skin types. It doesn't use UV rays, so there's no risk of burning or skin damage. However, we always conduct a thorough assessment before starting any treatment.",
    },
    {
      question: "Do I need to prepare anything before my session?",
      answer:
        "We recommend coming to your session with clean skin, free of any lotions, makeup, or sunscreen. Wear comfortable clothing that allows easy access to the treatment areas. Stay hydrated before and after your session.",
    },
    {
      question: "How long do the results last?",
      answer:
        "The longevity of results can vary depending on factors like lifestyle, diet, and maintenance treatments. Many clients find that periodic maintenance sessions help prolong the benefits of their initial treatment course.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-24">
        <div className="absolute inset-0 z-0 decorative-pattern opacity-10"></div>
        <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="flex flex-col items-center lg:flex-row lg:justify-between">
            <div className="mb-10 max-w-2xl lg:mb-0 lg:pr-8 lg:w-1/2">
              <h1 className="mb-6 text-4xl font-extrabold leading-tight text-gray-900 sm:text-5xl lg:text-6xl">
                Begin Your
                <br />
                <span className="bg-gradient-to-r from-red-600 to-red-400 bg-clip-text text-transparent">
                  Transformation
                </span>
                <br />& Love Your Body
              </h1>
              <p className="mb-8 text-xl text-gray-600">
                Experience cutting-edge, non-invasive Laser-Like Lipo & Red Light Therapy. Achieve your body goals
                without surgery or downtime.
              </p>
              <div className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
                <Button asChild size="lg" className="text-lg">
                  <Link href="/contact">
                    Start Your Journey <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="text-lg">
                  <Link href="/services">Explore Services</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-64 w-full max-w-lg overflow-hidden rounded-2xl shadow-2xl lg:h-[500px] lg:w-1/2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_1982.JPG-jhzj4guuFYKP20zCKnNNapba0idvic.jpeg"
                alt="Red light therapy treatment"
                fill
                className="object-cover transition-transform duration-300 hover:scale-105"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Features Section */}
      <section className="accent-bg py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-900">Why Choose Atlanta Laser-Like Lipo?</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: Zap,
                title: "Cutting-Edge Technology",
                description: "State-of-the-art Narrow Light Med Wave system for optimal results.",
              },
              {
                icon: CheckCircle,
                title: "Non-Invasive Solution",
                description: "Achieve your body goals without surgery or lengthy recovery times.",
              },
              {
                icon: Users,
                title: "Expert Guidance",
                description: "Our team of specialists provides personalized care and support.",
              },
              {
                icon: Sparkles,
                title: "Holistic Approach",
                description: "Comprehensive programs addressing overall health and wellness.",
              },
            ].map((feature, index) => (
              <div key={index} className="rounded-lg bg-white p-6 shadow-lg transition-all hover-card">
                <feature.icon className="mb-4 h-12 w-12 text-red-600" />
                <h3 className="mb-3 text-xl font-semibold text-gray-900">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="bg-gradient-to-br from-red-50 to-red-100 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gradient">What Our Clients Say</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                quote: "I've lost 4 inches in just 6 sessions! The results are amazing.",
                name: "Sarah T.",
              },
              {
                quote: "Not only did I lose weight, but my overall health has improved significantly.",
                name: "Michael R.",
              },
              {
                quote: "The staff is incredibly supportive and the treatments are so relaxing.",
                name: "Emily L.",
              },
            ].map((testimonial, index) => (
              <div key={index} className="relative rounded-lg bg-white p-6 shadow-lg transition-all hover-card">
                <div className="absolute -top-4 left-4 text-red-500">
                  <Quote size={32} />
                </div>
                <p className="mb-4 pt-4 text-lg italic text-gray-700">"{testimonial.quote}"</p>
                <p className="text-right text-sm font-semibold text-gray-900">- {testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-gray-50 py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-900">Frequently Asked Questions</h2>
          <div className="mx-auto max-w-3xl">
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-lg font-semibold">{faq.question}</AccordionTrigger>
                  <AccordionContent className="text-gray-600">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900 sm:text-4xl">Our Innovative Process</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {[
              { step: "01", title: "Consultation", description: "Personalized assessment of your goals and health." },
              { step: "02", title: "Custom Plan", description: "Tailored treatment program designed for your needs." },
              { step: "03", title: "Treatment", description: "Non-invasive sessions using advanced technology." },
              { step: "04", title: "Results", description: "Visible improvements and ongoing support." },
            ].map((step, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-red-600 text-2xl font-bold text-white">
                  {step.step}
                </div>
                <h3 className="mb-2 text-xl font-semibold text-gray-900">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-red-600 to-red-400 py-20 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Ready to Transform Your Body?</h2>
            <p className="mb-8 text-lg">
              Experience the future of body contouring and wellness. Start your journey to a healthier, more confident
              you today.
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link href="/contact">
                Book Your $89 Intro Session <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <p className="mt-4 text-sm opacity-80">48-hour cancellation policy applies. See terms for details.</p>
          </div>
        </div>
      </section>
    </div>
  )
}


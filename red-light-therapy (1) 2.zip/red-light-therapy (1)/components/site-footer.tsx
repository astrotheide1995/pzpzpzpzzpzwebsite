import Link from "next/link"
import { Facebook, Instagram, Twitter, Phone, Mail, MapPin } from "lucide-react"
import Image from "next/image"

export function SiteFooter() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Column 1 - About */}
          <div>
            <div className="flex items-center space-x-2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ATLANTA%20LASER%20LOGO.pdf%20%283%29-42ERnTngsvaq5lWjl7GbSVgcjGxlHB.png"
                alt="Atlanta Laser-Like Lipo"
                width={140}
                height={70}
                className="h-14 w-auto"
              />
            </div>
            <p className="mt-4">
              Specializing in advanced laser-like lipo treatments for weight loss, inch reduction, and overall wellness
              through non-invasive procedures in Atlanta, GA.
            </p>
            <div className="mt-6 flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Facebook</span>
                <Facebook className="h-6 w-6" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Instagram</span>
                <Instagram className="h-6 w-6" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <span className="sr-only">Twitter</span>
                <Twitter className="h-6 w-6" />
              </Link>
            </div>
          </div>

          {/* Column 2 - Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-white">Quick Links</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="/" className="hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/services" className="hover:text-white">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="/results" className="hover:text-white">
                  Client Results
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3 - Services */}
          <div>
            <h3 className="text-lg font-semibold text-white">Our Services</h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link href="/services#inch-loss" className="hover:text-white">
                  Red Light Inch Loss
                </Link>
              </li>
              <li>
                <Link href="/services#laser-lipo" className="hover:text-white">
                  Laser-Like Lipo
                </Link>
              </li>
              <li>
                <Link href="/services#wellness" className="hover:text-white">
                  Wellness Therapy
                </Link>
              </li>
              <li>
                <Link href="/services#consultation" className="hover:text-white">
                  Free Consultation
                </Link>
              </li>
              <li>
                <Link href="/services#packages" className="hover:text-white">
                  Treatment Packages
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4 - Contact */}
          <div>
            <h3 className="text-lg font-semibold text-white">Contact Us</h3>
            <h2 className="mt-6 text-xl font-semibold">Contact Information</h2>
            <div className="mt-4 space-y-4">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 shrink-0" />
                <Link href="tel:+1-770-702-4629">(770) 702-4629</Link>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 shrink-0" />
                <Link href="mailto:info@atlantalaserlipo.com">info@atlantalaserlipo.com</Link>
              </div>
            </div>

            <h2 className="mt-6 text-xl font-semibold">Our Location</h2>
            <div className="mt-4 flex items-start space-x-3">
              <MapPin className="h-5 w-5 shrink-0" />
              <p>
                3035 Five Forks Trickum Rd
                <br />
                Suite 7<br />
                Lilburn, GA 33047
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-800 pt-8 text-center">
          <p>© {new Date().getFullYear()} RedLight Therapy. All rights reserved.</p>
          <div className="mt-4 flex justify-center space-x-6">
            <Link href="/privacy" className="text-sm hover:text-white">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-sm hover:text-white">
              Terms of Service
            </Link>
            <Link href="/sitemap" className="text-sm hover:text-white">
              Sitemap
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}


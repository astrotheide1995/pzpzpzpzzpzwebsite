"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, Phone, X, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import Image from "next/image"

export function SiteHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const closeMenu = () => {
    setIsMenuOpen(false)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container flex h-16 items-center justify-between space-x-4 sm:space-x-0">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ATLANTA%20LASER%20LOGO.pdf%20%283%29-42ERnTngsvaq5lWjl7GbSVgcjGxlHB.png"
              alt="Atlanta Laser-Like Lipo"
              width={150}
              height={75}
              className="h-14 w-auto"
            />
            <span className="hidden font-bold sm:inline-block">Atlanta Laser-Like Lipo</span>
          </Link>
        </div>

        <div className="hidden gap-6 md:flex">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-red-600">
            Home
          </Link>
          <Link href="/about" className="text-sm font-medium transition-colors hover:text-red-600">
            About
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center text-sm font-medium transition-colors hover:text-red-600">
              Services <ChevronDown className="ml-1 h-4 w-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>
                <Link href="/services">All Services</Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/services/red-light-therapy">Red Light Therapy</Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/services/infrared-sauna">Infrared Sauna</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Link href="/contact" className="text-sm font-medium transition-colors hover:text-red-600">
            Contact
          </Link>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden items-center gap-4 md:flex">
            <Link
              href="tel:+1-770-702-4629"
              className="flex items-center space-x-1 text-sm font-medium text-gray-500 transition-colors hover:text-red-600"
            >
              <Phone className="h-4 w-4" />
              <span>(770) 702-4629</span>
            </Link>

            <Button asChild>
              <Link href="/contact">Book Now</Link>
            </Button>
          </div>

          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden" aria-label="Toggle Menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="grid gap-6 py-6">
                <div className="flex items-center justify-between">
                  <Link href="/" className="flex items-center space-x-2" onClick={closeMenu}>
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ATLANTA%20LASER%20LOGO.pdf%20%283%29-42ERnTngsvaq5lWjl7GbSVgcjGxlHB.png"
                      alt="Atlanta Laser-Like Lipo"
                      width={100}
                      height={50}
                      className="h-10 w-auto"
                    />
                    <span className="font-bold">Atlanta Laser-Like Lipo</span>
                  </Link>
                  <Button variant="ghost" size="icon" onClick={closeMenu} aria-label="Close Menu">
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <nav className="grid gap-4">
                  <Link href="/" className="text-lg font-medium" onClick={closeMenu}>
                    Home
                  </Link>
                  <Link href="/about" className="text-lg font-medium" onClick={closeMenu}>
                    About
                  </Link>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="services">
                      <AccordionTrigger className="text-lg font-medium">Services</AccordionTrigger>
                      <AccordionContent>
                        <div className="ml-4 grid gap-2">
                          <Link
                            href="/services"
                            className="text-base font-medium text-gray-600 hover:text-red-600"
                            onClick={closeMenu}
                          >
                            All Services
                          </Link>
                          <Link
                            href="/services/red-light-therapy"
                            className="text-base font-medium text-gray-600 hover:text-red-600"
                            onClick={closeMenu}
                          >
                            Red Light Therapy
                          </Link>
                          <Link
                            href="/services/infrared-sauna"
                            className="text-base font-medium text-gray-600 hover:text-red-600"
                            onClick={closeMenu}
                          >
                            Infrared Sauna
                          </Link>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                  <Link href="/contact" className="text-lg font-medium" onClick={closeMenu}>
                    Contact
                  </Link>
                </nav>

                <div className="flex flex-col gap-4">
                  <Link
                    href="tel:+1-770-702-4629"
                    className="flex items-center space-x-2 text-sm font-medium"
                    onClick={closeMenu}
                  >
                    <Phone className="h-4 w-4" />
                    <span>(770) 702-4629</span>
                  </Link>

                  <Button asChild onClick={closeMenu}>
                    <Link href="/contact">Claim Your $89 Treatment</Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

